# 601.229-hw5

Alexis Sanehisa contribution:
calc.cpp

Maudeline Deus Contribution:
calcServer.c