# 601.229-hw5

Alexis Sanehisa (asanehi1@jhu.edu) contribution:
calc.cpp

Maudeline Deus (mdeus1@jhu.edu) Contribution:
calcServer.c